﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPickup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gcTransaction = New System.Windows.Forms.GroupBox()
        Me.lblReference5 = New System.Windows.Forms.Label()
        Me.lblReference4 = New System.Windows.Forms.Label()
        Me.lblReference3 = New System.Windows.Forms.Label()
        Me.lblReference2 = New System.Windows.Forms.Label()
        Me.lblReference1 = New System.Windows.Forms.Label()
        Me.txtReference5 = New System.Windows.Forms.TextBox()
        Me.txtReference4 = New System.Windows.Forms.TextBox()
        Me.txtReference3 = New System.Windows.Forms.TextBox()
        Me.txtReference2 = New System.Windows.Forms.TextBox()
        Me.txtReference1 = New System.Windows.Forms.TextBox()
        Me.gcClientInfo = New System.Windows.Forms.GroupBox()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.lblAccountEntity = New System.Windows.Forms.Label()
        Me.lblAccountCountry = New System.Windows.Forms.Label()
        Me.lblAccountPin = New System.Windows.Forms.Label()
        Me.lblAccountNumber = New System.Windows.Forms.Label()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.txtVersion = New System.Windows.Forms.TextBox()
        Me.txtAccountEntity = New System.Windows.Forms.TextBox()
        Me.txtAccountCountryCode = New System.Windows.Forms.TextBox()
        Me.txtAccountPin = New System.Windows.Forms.TextBox()
        Me.txtAccountNumber = New System.Windows.Forms.TextBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.gcPickup = New System.Windows.Forms.GroupBox()
        Me.tcShipment = New System.Windows.Forms.TabControl()
        Me.tpPickupAddress = New System.Windows.Forms.TabPage()
        Me.gcPickupStatus = New System.Windows.Forms.GroupBox()
        Me.lblPickupStatus = New System.Windows.Forms.Label()
        Me.txtPickupStatus = New System.Windows.Forms.TextBox()
        Me.gcPickupContact = New System.Windows.Forms.GroupBox()
        Me.lblPickupContactType = New System.Windows.Forms.Label()
        Me.lblPickupContactEmailAddress = New System.Windows.Forms.Label()
        Me.lblPickupContactCellPhone = New System.Windows.Forms.Label()
        Me.lblPickupContactFaxNumber = New System.Windows.Forms.Label()
        Me.lblPickupContactPhoneNumber2 = New System.Windows.Forms.Label()
        Me.lblPickupContactPhoneNumber1 = New System.Windows.Forms.Label()
        Me.lblPickupContactCompanyName = New System.Windows.Forms.Label()
        Me.lblPickupContactTitle = New System.Windows.Forms.Label()
        Me.lblPickupContactPersonName = New System.Windows.Forms.Label()
        Me.lblPickupContactDepartment = New System.Windows.Forms.Label()
        Me.txtPickupContactType = New System.Windows.Forms.TextBox()
        Me.txtPickupContactEmailAddress = New System.Windows.Forms.TextBox()
        Me.txtPickupContactCellPhone = New System.Windows.Forms.TextBox()
        Me.txtPickupContactFaxNumber = New System.Windows.Forms.TextBox()
        Me.txtPickupContactPhoneNumber2Ext = New System.Windows.Forms.TextBox()
        Me.txtPickupContactPhoneNumber2 = New System.Windows.Forms.TextBox()
        Me.txtPickupContactPhoneNumber1Ext = New System.Windows.Forms.TextBox()
        Me.txtPickupContactPhoneNumber1 = New System.Windows.Forms.TextBox()
        Me.txtPickupContactCompanyName = New System.Windows.Forms.TextBox()
        Me.txtPickupContactTitle = New System.Windows.Forms.TextBox()
        Me.txtPickupContactPersonName = New System.Windows.Forms.TextBox()
        Me.txtPickupContactDepartment = New System.Windows.Forms.TextBox()
        Me.gcPickupDateTime = New System.Windows.Forms.GroupBox()
        Me.lblPickupComments = New System.Windows.Forms.Label()
        Me.txtPickupComments = New System.Windows.Forms.TextBox()
        Me.lblPickupClosingTime = New System.Windows.Forms.Label()
        Me.dtpPickupClosingTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpPickupLatestTime = New System.Windows.Forms.DateTimePicker()
        Me.lblPickupLatestTime = New System.Windows.Forms.Label()
        Me.lblPickupReadyTime = New System.Windows.Forms.Label()
        Me.lblPickupDate = New System.Windows.Forms.Label()
        Me.dtpPickupReadyTime = New System.Windows.Forms.DateTimePicker()
        Me.dtpPickupDate = New System.Windows.Forms.DateTimePicker()
        Me.gcPickupVehicle = New System.Windows.Forms.GroupBox()
        Me.lblPickupVehicle = New System.Windows.Forms.Label()
        Me.txtPickupVehicle = New System.Windows.Forms.TextBox()
        Me.gcPickupReferences = New System.Windows.Forms.GroupBox()
        Me.lblPickupReference2 = New System.Windows.Forms.Label()
        Me.lblPickupReference1 = New System.Windows.Forms.Label()
        Me.txtPickupReference2 = New System.Windows.Forms.TextBox()
        Me.txtPickupReference1 = New System.Windows.Forms.TextBox()
        Me.gcPickupAddress = New System.Windows.Forms.GroupBox()
        Me.lblPickupLocation = New System.Windows.Forms.Label()
        Me.txtPickupLocation = New System.Windows.Forms.TextBox()
        Me.lblPickupAddressCountry = New System.Windows.Forms.Label()
        Me.lblPickupAddressPostCode = New System.Windows.Forms.Label()
        Me.lblPickupAddressState = New System.Windows.Forms.Label()
        Me.lblPickupAddressCity = New System.Windows.Forms.Label()
        Me.lblPickupAddressLine3 = New System.Windows.Forms.Label()
        Me.lblPickupAddressLine2 = New System.Windows.Forms.Label()
        Me.lblPickupAddressLine1 = New System.Windows.Forms.Label()
        Me.txtPickupAddressCountry = New System.Windows.Forms.TextBox()
        Me.txtPickupAddressPostCode = New System.Windows.Forms.TextBox()
        Me.txtPickupAddressState = New System.Windows.Forms.TextBox()
        Me.txtPickupAddressCity = New System.Windows.Forms.TextBox()
        Me.txtPickupAddressLine3 = New System.Windows.Forms.TextBox()
        Me.txtPickupAddressLine2 = New System.Windows.Forms.TextBox()
        Me.txtPickupAddressLine1 = New System.Windows.Forms.TextBox()
        Me.tpPickupItems = New System.Windows.Forms.TabPage()
        Me.gcShipmentDetailsTypes = New System.Windows.Forms.GroupBox()
        Me.lblPickupItemDetailComments = New System.Windows.Forms.Label()
        Me.lblPickupItemDetailNumberOfPieces = New System.Windows.Forms.Label()
        Me.lvPickupItems = New System.Windows.Forms.ListView()
        Me.colProductGroup = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colProductType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colPaymentType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colPackageType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colNumberOfShipments = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colNumberOfPieces = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colWeight = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colVolume = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCashAmount = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colExtraCharges = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDimensions = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colComments = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btnPickupDetailDelete = New System.Windows.Forms.Button()
        Me.btnPickupDetailAdd = New System.Windows.Forms.Button()
        Me.txtPickupItemDetailComments = New System.Windows.Forms.TextBox()
        Me.gcPickupItemDetailDimensions = New System.Windows.Forms.GroupBox()
        Me.lblPickupItemDetailUnit = New System.Windows.Forms.Label()
        Me.lblPickupItemDetailWidth = New System.Windows.Forms.Label()
        Me.lblPickupItemDetailHeight = New System.Windows.Forms.Label()
        Me.lblPickupItemDetailLength = New System.Windows.Forms.Label()
        Me.cmbPickupItemDetailUnit = New System.Windows.Forms.ComboBox()
        Me.nudPickupItemDetailWidth = New System.Windows.Forms.NumericUpDown()
        Me.nudPickupItemDetailHeight = New System.Windows.Forms.NumericUpDown()
        Me.nudPickupItemDetailLength = New System.Windows.Forms.NumericUpDown()
        Me.nudPickupItemDetailExtraCharges = New System.Windows.Forms.NumericUpDown()
        Me.lblPickupItemDetailExtraCharges = New System.Windows.Forms.Label()
        Me.txtPickupItemDetailExtraChargesCurrency = New System.Windows.Forms.TextBox()
        Me.nudPickupItemDetailCashAmount = New System.Windows.Forms.NumericUpDown()
        Me.lblPickupItemDetailCashAmount = New System.Windows.Forms.Label()
        Me.txtPickupItemDetailCashAmountCurrency = New System.Windows.Forms.TextBox()
        Me.lblPickupItemDetailVolume = New System.Windows.Forms.Label()
        Me.lblPickupItemDetailVolumeUnit = New System.Windows.Forms.Label()
        Me.cmbPickupItemDetailVolumeUnit = New System.Windows.Forms.ComboBox()
        Me.nudPickupItemDetailVolume = New System.Windows.Forms.NumericUpDown()
        Me.lblPickupItemDetailWeight = New System.Windows.Forms.Label()
        Me.lblPickupItemDetailWeightUnit = New System.Windows.Forms.Label()
        Me.cmbPickupItemDetailWeightUnit = New System.Windows.Forms.ComboBox()
        Me.nudPickupItemDetailWeight = New System.Windows.Forms.NumericUpDown()
        Me.lblPickupItemDetailPackageType = New System.Windows.Forms.Label()
        Me.txtPickupItemDetailPackageType = New System.Windows.Forms.TextBox()
        Me.nudPickupItemDetailNumberOfPieces = New System.Windows.Forms.NumericUpDown()
        Me.lblPickupItemDetailNumberOfShipments = New System.Windows.Forms.Label()
        Me.nudPickupItemDetailNumberOfShipments = New System.Windows.Forms.NumericUpDown()
        Me.lblPickupItemDetailPaymentType = New System.Windows.Forms.Label()
        Me.lblPickupItemDetailProductType = New System.Windows.Forms.Label()
        Me.lblPickupItemDetailProductGroup = New System.Windows.Forms.Label()
        Me.txtPickupItemDetailPaymentType = New System.Windows.Forms.TextBox()
        Me.txtPickupItemDetailProductType = New System.Windows.Forms.TextBox()
        Me.txtPickupItemDetailProductGroup = New System.Windows.Forms.TextBox()
        Me.gcActions = New System.Windows.Forms.GroupBox()
        Me.btnAddShipments = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnSubmitRequest = New System.Windows.Forms.Button()
        Me.gcLabelInfo = New System.Windows.Forms.GroupBox()
        Me.rbReportAsFile = New System.Windows.Forms.RadioButton()
        Me.rbReportAsURL = New System.Windows.Forms.RadioButton()
        Me.lblReportID = New System.Windows.Forms.Label()
        Me.nudReportID = New System.Windows.Forms.NumericUpDown()
        Me.chkbGenerateLabels = New System.Windows.Forms.CheckBox()
        Me.gcTransaction.SuspendLayout()
        Me.gcClientInfo.SuspendLayout()
        Me.gcPickup.SuspendLayout()
        Me.tcShipment.SuspendLayout()
        Me.tpPickupAddress.SuspendLayout()
        Me.gcPickupStatus.SuspendLayout()
        Me.gcPickupContact.SuspendLayout()
        Me.gcPickupDateTime.SuspendLayout()
        Me.gcPickupVehicle.SuspendLayout()
        Me.gcPickupReferences.SuspendLayout()
        Me.gcPickupAddress.SuspendLayout()
        Me.tpPickupItems.SuspendLayout()
        Me.gcShipmentDetailsTypes.SuspendLayout()
        Me.gcPickupItemDetailDimensions.SuspendLayout()
        CType(Me.nudPickupItemDetailWidth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPickupItemDetailHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPickupItemDetailLength, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPickupItemDetailExtraCharges, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPickupItemDetailCashAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPickupItemDetailVolume, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPickupItemDetailWeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPickupItemDetailNumberOfPieces, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPickupItemDetailNumberOfShipments, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gcActions.SuspendLayout()
        Me.gcLabelInfo.SuspendLayout()
        CType(Me.nudReportID, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gcTransaction
        '
        Me.gcTransaction.Controls.Add(Me.lblReference5)
        Me.gcTransaction.Controls.Add(Me.lblReference4)
        Me.gcTransaction.Controls.Add(Me.lblReference3)
        Me.gcTransaction.Controls.Add(Me.lblReference2)
        Me.gcTransaction.Controls.Add(Me.lblReference1)
        Me.gcTransaction.Controls.Add(Me.txtReference5)
        Me.gcTransaction.Controls.Add(Me.txtReference4)
        Me.gcTransaction.Controls.Add(Me.txtReference3)
        Me.gcTransaction.Controls.Add(Me.txtReference2)
        Me.gcTransaction.Controls.Add(Me.txtReference1)
        Me.gcTransaction.Location = New System.Drawing.Point(412, 12)
        Me.gcTransaction.Name = "gcTransaction"
        Me.gcTransaction.Size = New System.Drawing.Size(394, 144)
        Me.gcTransaction.TabIndex = 1
        Me.gcTransaction.TabStop = False
        Me.gcTransaction.Text = "Transaction"
        '
        'lblReference5
        '
        Me.lblReference5.AutoSize = True
        Me.lblReference5.Location = New System.Drawing.Point(6, 122)
        Me.lblReference5.Name = "lblReference5"
        Me.lblReference5.Size = New System.Drawing.Size(66, 13)
        Me.lblReference5.TabIndex = 8
        Me.lblReference5.Text = "Reference5:"
        '
        'lblReference4
        '
        Me.lblReference4.AutoSize = True
        Me.lblReference4.Location = New System.Drawing.Point(6, 96)
        Me.lblReference4.Name = "lblReference4"
        Me.lblReference4.Size = New System.Drawing.Size(66, 13)
        Me.lblReference4.TabIndex = 6
        Me.lblReference4.Text = "Reference4:"
        '
        'lblReference3
        '
        Me.lblReference3.AutoSize = True
        Me.lblReference3.Location = New System.Drawing.Point(6, 70)
        Me.lblReference3.Name = "lblReference3"
        Me.lblReference3.Size = New System.Drawing.Size(66, 13)
        Me.lblReference3.TabIndex = 4
        Me.lblReference3.Text = "Reference3:"
        '
        'lblReference2
        '
        Me.lblReference2.AutoSize = True
        Me.lblReference2.Location = New System.Drawing.Point(6, 44)
        Me.lblReference2.Name = "lblReference2"
        Me.lblReference2.Size = New System.Drawing.Size(66, 13)
        Me.lblReference2.TabIndex = 2
        Me.lblReference2.Text = "Reference2:"
        '
        'lblReference1
        '
        Me.lblReference1.AutoSize = True
        Me.lblReference1.Location = New System.Drawing.Point(6, 18)
        Me.lblReference1.Name = "lblReference1"
        Me.lblReference1.Size = New System.Drawing.Size(66, 13)
        Me.lblReference1.TabIndex = 0
        Me.lblReference1.Text = "Reference1:"
        '
        'txtReference5
        '
        Me.txtReference5.Location = New System.Drawing.Point(78, 118)
        Me.txtReference5.Name = "txtReference5"
        Me.txtReference5.Size = New System.Drawing.Size(310, 20)
        Me.txtReference5.TabIndex = 9
        '
        'txtReference4
        '
        Me.txtReference4.Location = New System.Drawing.Point(78, 92)
        Me.txtReference4.Name = "txtReference4"
        Me.txtReference4.Size = New System.Drawing.Size(310, 20)
        Me.txtReference4.TabIndex = 7
        '
        'txtReference3
        '
        Me.txtReference3.Location = New System.Drawing.Point(78, 66)
        Me.txtReference3.Name = "txtReference3"
        Me.txtReference3.Size = New System.Drawing.Size(310, 20)
        Me.txtReference3.TabIndex = 5
        '
        'txtReference2
        '
        Me.txtReference2.Location = New System.Drawing.Point(78, 40)
        Me.txtReference2.Name = "txtReference2"
        Me.txtReference2.Size = New System.Drawing.Size(310, 20)
        Me.txtReference2.TabIndex = 3
        '
        'txtReference1
        '
        Me.txtReference1.Location = New System.Drawing.Point(78, 14)
        Me.txtReference1.Name = "txtReference1"
        Me.txtReference1.Size = New System.Drawing.Size(310, 20)
        Me.txtReference1.TabIndex = 1
        '
        'gcClientInfo
        '
        Me.gcClientInfo.Controls.Add(Me.lblVersion)
        Me.gcClientInfo.Controls.Add(Me.lblAccountEntity)
        Me.gcClientInfo.Controls.Add(Me.lblAccountCountry)
        Me.gcClientInfo.Controls.Add(Me.lblAccountPin)
        Me.gcClientInfo.Controls.Add(Me.lblAccountNumber)
        Me.gcClientInfo.Controls.Add(Me.lblPassword)
        Me.gcClientInfo.Controls.Add(Me.lblUsername)
        Me.gcClientInfo.Controls.Add(Me.txtVersion)
        Me.gcClientInfo.Controls.Add(Me.txtAccountEntity)
        Me.gcClientInfo.Controls.Add(Me.txtAccountCountryCode)
        Me.gcClientInfo.Controls.Add(Me.txtAccountPin)
        Me.gcClientInfo.Controls.Add(Me.txtAccountNumber)
        Me.gcClientInfo.Controls.Add(Me.txtPassword)
        Me.gcClientInfo.Controls.Add(Me.txtUsername)
        Me.gcClientInfo.Location = New System.Drawing.Point(12, 12)
        Me.gcClientInfo.Name = "gcClientInfo"
        Me.gcClientInfo.Size = New System.Drawing.Size(394, 198)
        Me.gcClientInfo.TabIndex = 0
        Me.gcClientInfo.TabStop = False
        Me.gcClientInfo.Text = "ClientInfo"
        '
        'lblVersion
        '
        Me.lblVersion.AutoSize = True
        Me.lblVersion.Location = New System.Drawing.Point(6, 174)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(45, 13)
        Me.lblVersion.TabIndex = 12
        Me.lblVersion.Text = "Version:"
        '
        'lblAccountEntity
        '
        Me.lblAccountEntity.AutoSize = True
        Me.lblAccountEntity.Location = New System.Drawing.Point(6, 147)
        Me.lblAccountEntity.Name = "lblAccountEntity"
        Me.lblAccountEntity.Size = New System.Drawing.Size(61, 13)
        Me.lblAccountEntity.TabIndex = 10
        Me.lblAccountEntity.Text = "Acc. Entity:"
        '
        'lblAccountCountry
        '
        Me.lblAccountCountry.AutoSize = True
        Me.lblAccountCountry.Location = New System.Drawing.Point(6, 122)
        Me.lblAccountCountry.Name = "lblAccountCountry"
        Me.lblAccountCountry.Size = New System.Drawing.Size(71, 13)
        Me.lblAccountCountry.TabIndex = 8
        Me.lblAccountCountry.Text = "Acc. Country:"
        '
        'lblAccountPin
        '
        Me.lblAccountPin.AutoSize = True
        Me.lblAccountPin.Location = New System.Drawing.Point(6, 96)
        Me.lblAccountPin.Name = "lblAccountPin"
        Me.lblAccountPin.Size = New System.Drawing.Size(50, 13)
        Me.lblAccountPin.TabIndex = 6
        Me.lblAccountPin.Text = "Acc. Pin:"
        '
        'lblAccountNumber
        '
        Me.lblAccountNumber.AutoSize = True
        Me.lblAccountNumber.Location = New System.Drawing.Point(6, 70)
        Me.lblAccountNumber.Name = "lblAccountNumber"
        Me.lblAccountNumber.Size = New System.Drawing.Size(52, 13)
        Me.lblAccountNumber.TabIndex = 4
        Me.lblAccountNumber.Text = "Acc. No.:"
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(6, 43)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(56, 13)
        Me.lblPassword.TabIndex = 2
        Me.lblPassword.Text = "Password:"
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.lblUsername.Location = New System.Drawing.Point(6, 18)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(58, 13)
        Me.lblUsername.TabIndex = 0
        Me.lblUsername.Text = "Username:"
        '
        'txtVersion
        '
        Me.txtVersion.Location = New System.Drawing.Point(78, 170)
        Me.txtVersion.Name = "txtVersion"
        Me.txtVersion.Size = New System.Drawing.Size(306, 20)
        Me.txtVersion.TabIndex = 13
        Me.txtVersion.Text = "1.0"
        '
        'txtAccountEntity
        '
        Me.txtAccountEntity.Location = New System.Drawing.Point(78, 144)
        Me.txtAccountEntity.Name = "txtAccountEntity"
        Me.txtAccountEntity.Size = New System.Drawing.Size(306, 20)
        Me.txtAccountEntity.TabIndex = 11
        Me.txtAccountEntity.Text = "AMM"
        '
        'txtAccountCountryCode
        '
        Me.txtAccountCountryCode.Location = New System.Drawing.Point(78, 118)
        Me.txtAccountCountryCode.Name = "txtAccountCountryCode"
        Me.txtAccountCountryCode.Size = New System.Drawing.Size(306, 20)
        Me.txtAccountCountryCode.TabIndex = 9
        Me.txtAccountCountryCode.Text = "JO"
        '
        'txtAccountPin
        '
        Me.txtAccountPin.Location = New System.Drawing.Point(78, 92)
        Me.txtAccountPin.Name = "txtAccountPin"
        Me.txtAccountPin.Size = New System.Drawing.Size(306, 20)
        Me.txtAccountPin.TabIndex = 7
        Me.txtAccountPin.Text = "221321"
        '
        'txtAccountNumber
        '
        Me.txtAccountNumber.Location = New System.Drawing.Point(78, 66)
        Me.txtAccountNumber.Name = "txtAccountNumber"
        Me.txtAccountNumber.Size = New System.Drawing.Size(306, 20)
        Me.txtAccountNumber.TabIndex = 5
        Me.txtAccountNumber.Text = "20016"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(78, 40)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(306, 20)
        Me.txtPassword.TabIndex = 3
        Me.txtPassword.Text = "123456789"
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(78, 14)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(306, 20)
        Me.txtUsername.TabIndex = 1
        Me.txtUsername.Text = "reem@reem.com"
        '
        'gcPickup
        '
        Me.gcPickup.Controls.Add(Me.tcShipment)
        Me.gcPickup.Location = New System.Drawing.Point(12, 216)
        Me.gcPickup.Name = "gcPickup"
        Me.gcPickup.Size = New System.Drawing.Size(794, 436)
        Me.gcPickup.TabIndex = 3
        Me.gcPickup.TabStop = False
        Me.gcPickup.Text = "Pickup"
        '
        'tcShipment
        '
        Me.tcShipment.Controls.Add(Me.tpPickupAddress)
        Me.tcShipment.Controls.Add(Me.tpPickupItems)
        Me.tcShipment.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tcShipment.Location = New System.Drawing.Point(3, 16)
        Me.tcShipment.Name = "tcShipment"
        Me.tcShipment.SelectedIndex = 0
        Me.tcShipment.Size = New System.Drawing.Size(788, 417)
        Me.tcShipment.TabIndex = 0
        '
        'tpPickupAddress
        '
        Me.tpPickupAddress.Controls.Add(Me.gcPickupStatus)
        Me.tpPickupAddress.Controls.Add(Me.gcPickupContact)
        Me.tpPickupAddress.Controls.Add(Me.gcPickupDateTime)
        Me.tpPickupAddress.Controls.Add(Me.gcPickupVehicle)
        Me.tpPickupAddress.Controls.Add(Me.gcPickupReferences)
        Me.tpPickupAddress.Controls.Add(Me.gcPickupAddress)
        Me.tpPickupAddress.Location = New System.Drawing.Point(4, 22)
        Me.tpPickupAddress.Name = "tpPickupAddress"
        Me.tpPickupAddress.Padding = New System.Windows.Forms.Padding(3)
        Me.tpPickupAddress.Size = New System.Drawing.Size(780, 391)
        Me.tpPickupAddress.TabIndex = 1
        Me.tpPickupAddress.Text = "Pickup Details"
        Me.tpPickupAddress.UseVisualStyleBackColor = True
        '
        'gcPickupStatus
        '
        Me.gcPickupStatus.Controls.Add(Me.lblPickupStatus)
        Me.gcPickupStatus.Controls.Add(Me.txtPickupStatus)
        Me.gcPickupStatus.Location = New System.Drawing.Point(6, 351)
        Me.gcPickupStatus.Name = "gcPickupStatus"
        Me.gcPickupStatus.Size = New System.Drawing.Size(322, 37)
        Me.gcPickupStatus.TabIndex = 3
        Me.gcPickupStatus.TabStop = False
        Me.gcPickupStatus.Text = "Status"
        '
        'lblPickupStatus
        '
        Me.lblPickupStatus.AutoSize = True
        Me.lblPickupStatus.Location = New System.Drawing.Point(6, 15)
        Me.lblPickupStatus.Name = "lblPickupStatus"
        Me.lblPickupStatus.Size = New System.Drawing.Size(40, 13)
        Me.lblPickupStatus.TabIndex = 0
        Me.lblPickupStatus.Text = "Status:"
        '
        'txtPickupStatus
        '
        Me.txtPickupStatus.Location = New System.Drawing.Point(99, 11)
        Me.txtPickupStatus.Name = "txtPickupStatus"
        Me.txtPickupStatus.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupStatus.TabIndex = 1
        '
        'gcPickupContact
        '
        Me.gcPickupContact.Controls.Add(Me.lblPickupContactType)
        Me.gcPickupContact.Controls.Add(Me.lblPickupContactEmailAddress)
        Me.gcPickupContact.Controls.Add(Me.lblPickupContactCellPhone)
        Me.gcPickupContact.Controls.Add(Me.lblPickupContactFaxNumber)
        Me.gcPickupContact.Controls.Add(Me.lblPickupContactPhoneNumber2)
        Me.gcPickupContact.Controls.Add(Me.lblPickupContactPhoneNumber1)
        Me.gcPickupContact.Controls.Add(Me.lblPickupContactCompanyName)
        Me.gcPickupContact.Controls.Add(Me.lblPickupContactTitle)
        Me.gcPickupContact.Controls.Add(Me.lblPickupContactPersonName)
        Me.gcPickupContact.Controls.Add(Me.lblPickupContactDepartment)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactType)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactEmailAddress)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactCellPhone)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactFaxNumber)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactPhoneNumber2Ext)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactPhoneNumber2)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactPhoneNumber1Ext)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactPhoneNumber1)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactCompanyName)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactTitle)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactPersonName)
        Me.gcPickupContact.Controls.Add(Me.txtPickupContactDepartment)
        Me.gcPickupContact.Location = New System.Drawing.Point(334, 102)
        Me.gcPickupContact.Name = "gcPickupContact"
        Me.gcPickupContact.Size = New System.Drawing.Size(381, 287)
        Me.gcPickupContact.TabIndex = 5
        Me.gcPickupContact.TabStop = False
        Me.gcPickupContact.Text = "Contact"
        '
        'lblPickupContactType
        '
        Me.lblPickupContactType.AutoSize = True
        Me.lblPickupContactType.Location = New System.Drawing.Point(6, 257)
        Me.lblPickupContactType.Name = "lblPickupContactType"
        Me.lblPickupContactType.Size = New System.Drawing.Size(34, 13)
        Me.lblPickupContactType.TabIndex = 20
        Me.lblPickupContactType.Text = "Type:"
        '
        'lblPickupContactEmailAddress
        '
        Me.lblPickupContactEmailAddress.AutoSize = True
        Me.lblPickupContactEmailAddress.Location = New System.Drawing.Point(6, 231)
        Me.lblPickupContactEmailAddress.Name = "lblPickupContactEmailAddress"
        Me.lblPickupContactEmailAddress.Size = New System.Drawing.Size(76, 13)
        Me.lblPickupContactEmailAddress.TabIndex = 18
        Me.lblPickupContactEmailAddress.Text = "Email Address:"
        '
        'lblPickupContactCellPhone
        '
        Me.lblPickupContactCellPhone.AutoSize = True
        Me.lblPickupContactCellPhone.Location = New System.Drawing.Point(6, 205)
        Me.lblPickupContactCellPhone.Name = "lblPickupContactCellPhone"
        Me.lblPickupContactCellPhone.Size = New System.Drawing.Size(61, 13)
        Me.lblPickupContactCellPhone.TabIndex = 16
        Me.lblPickupContactCellPhone.Text = "Cell Phone:"
        '
        'lblPickupContactFaxNumber
        '
        Me.lblPickupContactFaxNumber.AutoSize = True
        Me.lblPickupContactFaxNumber.Location = New System.Drawing.Point(6, 179)
        Me.lblPickupContactFaxNumber.Name = "lblPickupContactFaxNumber"
        Me.lblPickupContactFaxNumber.Size = New System.Drawing.Size(67, 13)
        Me.lblPickupContactFaxNumber.TabIndex = 14
        Me.lblPickupContactFaxNumber.Text = "Fax Number:"
        '
        'lblPickupContactPhoneNumber2
        '
        Me.lblPickupContactPhoneNumber2.AutoSize = True
        Me.lblPickupContactPhoneNumber2.Location = New System.Drawing.Point(6, 153)
        Me.lblPickupContactPhoneNumber2.Name = "lblPickupContactPhoneNumber2"
        Me.lblPickupContactPhoneNumber2.Size = New System.Drawing.Size(87, 13)
        Me.lblPickupContactPhoneNumber2.TabIndex = 11
        Me.lblPickupContactPhoneNumber2.Text = "Phone Number2:"
        '
        'lblPickupContactPhoneNumber1
        '
        Me.lblPickupContactPhoneNumber1.AutoSize = True
        Me.lblPickupContactPhoneNumber1.Location = New System.Drawing.Point(6, 127)
        Me.lblPickupContactPhoneNumber1.Name = "lblPickupContactPhoneNumber1"
        Me.lblPickupContactPhoneNumber1.Size = New System.Drawing.Size(87, 13)
        Me.lblPickupContactPhoneNumber1.TabIndex = 8
        Me.lblPickupContactPhoneNumber1.Text = "Phone Number1:"
        '
        'lblPickupContactCompanyName
        '
        Me.lblPickupContactCompanyName.AutoSize = True
        Me.lblPickupContactCompanyName.Location = New System.Drawing.Point(6, 101)
        Me.lblPickupContactCompanyName.Name = "lblPickupContactCompanyName"
        Me.lblPickupContactCompanyName.Size = New System.Drawing.Size(85, 13)
        Me.lblPickupContactCompanyName.TabIndex = 6
        Me.lblPickupContactCompanyName.Text = "Company Name:"
        '
        'lblPickupContactTitle
        '
        Me.lblPickupContactTitle.AutoSize = True
        Me.lblPickupContactTitle.Location = New System.Drawing.Point(6, 75)
        Me.lblPickupContactTitle.Name = "lblPickupContactTitle"
        Me.lblPickupContactTitle.Size = New System.Drawing.Size(30, 13)
        Me.lblPickupContactTitle.TabIndex = 4
        Me.lblPickupContactTitle.Text = "Title:"
        '
        'lblPickupContactPersonName
        '
        Me.lblPickupContactPersonName.AutoSize = True
        Me.lblPickupContactPersonName.Location = New System.Drawing.Point(6, 49)
        Me.lblPickupContactPersonName.Name = "lblPickupContactPersonName"
        Me.lblPickupContactPersonName.Size = New System.Drawing.Size(74, 13)
        Me.lblPickupContactPersonName.TabIndex = 2
        Me.lblPickupContactPersonName.Text = "Person Name:"
        '
        'lblPickupContactDepartment
        '
        Me.lblPickupContactDepartment.AutoSize = True
        Me.lblPickupContactDepartment.Location = New System.Drawing.Point(6, 23)
        Me.lblPickupContactDepartment.Name = "lblPickupContactDepartment"
        Me.lblPickupContactDepartment.Size = New System.Drawing.Size(65, 13)
        Me.lblPickupContactDepartment.TabIndex = 0
        Me.lblPickupContactDepartment.Text = "Department:"
        '
        'txtPickupContactType
        '
        Me.txtPickupContactType.Location = New System.Drawing.Point(100, 253)
        Me.txtPickupContactType.Name = "txtPickupContactType"
        Me.txtPickupContactType.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupContactType.TabIndex = 21
        '
        'txtPickupContactEmailAddress
        '
        Me.txtPickupContactEmailAddress.Location = New System.Drawing.Point(100, 227)
        Me.txtPickupContactEmailAddress.Name = "txtPickupContactEmailAddress"
        Me.txtPickupContactEmailAddress.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupContactEmailAddress.TabIndex = 19
        '
        'txtPickupContactCellPhone
        '
        Me.txtPickupContactCellPhone.Location = New System.Drawing.Point(100, 201)
        Me.txtPickupContactCellPhone.Name = "txtPickupContactCellPhone"
        Me.txtPickupContactCellPhone.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupContactCellPhone.TabIndex = 17
        '
        'txtPickupContactFaxNumber
        '
        Me.txtPickupContactFaxNumber.Location = New System.Drawing.Point(100, 175)
        Me.txtPickupContactFaxNumber.Name = "txtPickupContactFaxNumber"
        Me.txtPickupContactFaxNumber.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupContactFaxNumber.TabIndex = 15
        '
        'txtPickupContactPhoneNumber2Ext
        '
        Me.txtPickupContactPhoneNumber2Ext.Location = New System.Drawing.Point(319, 149)
        Me.txtPickupContactPhoneNumber2Ext.Name = "txtPickupContactPhoneNumber2Ext"
        Me.txtPickupContactPhoneNumber2Ext.Size = New System.Drawing.Size(56, 20)
        Me.txtPickupContactPhoneNumber2Ext.TabIndex = 13
        '
        'txtPickupContactPhoneNumber2
        '
        Me.txtPickupContactPhoneNumber2.Location = New System.Drawing.Point(100, 149)
        Me.txtPickupContactPhoneNumber2.Name = "txtPickupContactPhoneNumber2"
        Me.txtPickupContactPhoneNumber2.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupContactPhoneNumber2.TabIndex = 12
        '
        'txtPickupContactPhoneNumber1Ext
        '
        Me.txtPickupContactPhoneNumber1Ext.Location = New System.Drawing.Point(319, 123)
        Me.txtPickupContactPhoneNumber1Ext.Name = "txtPickupContactPhoneNumber1Ext"
        Me.txtPickupContactPhoneNumber1Ext.Size = New System.Drawing.Size(56, 20)
        Me.txtPickupContactPhoneNumber1Ext.TabIndex = 10
        '
        'txtPickupContactPhoneNumber1
        '
        Me.txtPickupContactPhoneNumber1.Location = New System.Drawing.Point(100, 123)
        Me.txtPickupContactPhoneNumber1.Name = "txtPickupContactPhoneNumber1"
        Me.txtPickupContactPhoneNumber1.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupContactPhoneNumber1.TabIndex = 9
        '
        'txtPickupContactCompanyName
        '
        Me.txtPickupContactCompanyName.Location = New System.Drawing.Point(100, 97)
        Me.txtPickupContactCompanyName.Name = "txtPickupContactCompanyName"
        Me.txtPickupContactCompanyName.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupContactCompanyName.TabIndex = 7
        '
        'txtPickupContactTitle
        '
        Me.txtPickupContactTitle.Location = New System.Drawing.Point(100, 71)
        Me.txtPickupContactTitle.Name = "txtPickupContactTitle"
        Me.txtPickupContactTitle.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupContactTitle.TabIndex = 5
        '
        'txtPickupContactPersonName
        '
        Me.txtPickupContactPersonName.Location = New System.Drawing.Point(100, 45)
        Me.txtPickupContactPersonName.Name = "txtPickupContactPersonName"
        Me.txtPickupContactPersonName.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupContactPersonName.TabIndex = 3
        '
        'txtPickupContactDepartment
        '
        Me.txtPickupContactDepartment.Location = New System.Drawing.Point(100, 19)
        Me.txtPickupContactDepartment.Name = "txtPickupContactDepartment"
        Me.txtPickupContactDepartment.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupContactDepartment.TabIndex = 1
        '
        'gcPickupDateTime
        '
        Me.gcPickupDateTime.Controls.Add(Me.lblPickupComments)
        Me.gcPickupDateTime.Controls.Add(Me.txtPickupComments)
        Me.gcPickupDateTime.Controls.Add(Me.lblPickupClosingTime)
        Me.gcPickupDateTime.Controls.Add(Me.dtpPickupClosingTime)
        Me.gcPickupDateTime.Controls.Add(Me.dtpPickupLatestTime)
        Me.gcPickupDateTime.Controls.Add(Me.lblPickupLatestTime)
        Me.gcPickupDateTime.Controls.Add(Me.lblPickupReadyTime)
        Me.gcPickupDateTime.Controls.Add(Me.lblPickupDate)
        Me.gcPickupDateTime.Controls.Add(Me.dtpPickupReadyTime)
        Me.gcPickupDateTime.Controls.Add(Me.dtpPickupDate)
        Me.gcPickupDateTime.Location = New System.Drawing.Point(334, 6)
        Me.gcPickupDateTime.Name = "gcPickupDateTime"
        Me.gcPickupDateTime.Size = New System.Drawing.Size(381, 97)
        Me.gcPickupDateTime.TabIndex = 4
        Me.gcPickupDateTime.TabStop = False
        Me.gcPickupDateTime.Text = "Date && Time"
        '
        'lblPickupComments
        '
        Me.lblPickupComments.AutoSize = True
        Me.lblPickupComments.Location = New System.Drawing.Point(6, 69)
        Me.lblPickupComments.Name = "lblPickupComments"
        Me.lblPickupComments.Size = New System.Drawing.Size(59, 13)
        Me.lblPickupComments.TabIndex = 8
        Me.lblPickupComments.Text = "Comments:"
        '
        'txtPickupComments
        '
        Me.txtPickupComments.Location = New System.Drawing.Point(99, 63)
        Me.txtPickupComments.Multiline = True
        Me.txtPickupComments.Name = "txtPickupComments"
        Me.txtPickupComments.Size = New System.Drawing.Size(255, 25)
        Me.txtPickupComments.TabIndex = 9
        '
        'lblPickupClosingTime
        '
        Me.lblPickupClosingTime.AutoSize = True
        Me.lblPickupClosingTime.Location = New System.Drawing.Point(193, 43)
        Me.lblPickupClosingTime.Name = "lblPickupClosingTime"
        Me.lblPickupClosingTime.Size = New System.Drawing.Size(70, 13)
        Me.lblPickupClosingTime.TabIndex = 6
        Me.lblPickupClosingTime.Text = "Closing Time:"
        '
        'dtpPickupClosingTime
        '
        Me.dtpPickupClosingTime.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpPickupClosingTime.Location = New System.Drawing.Point(266, 39)
        Me.dtpPickupClosingTime.Name = "dtpPickupClosingTime"
        Me.dtpPickupClosingTime.ShowUpDown = True
        Me.dtpPickupClosingTime.Size = New System.Drawing.Size(88, 20)
        Me.dtpPickupClosingTime.TabIndex = 7
        '
        'dtpPickupLatestTime
        '
        Me.dtpPickupLatestTime.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpPickupLatestTime.Location = New System.Drawing.Point(99, 39)
        Me.dtpPickupLatestTime.Name = "dtpPickupLatestTime"
        Me.dtpPickupLatestTime.ShowUpDown = True
        Me.dtpPickupLatestTime.Size = New System.Drawing.Size(88, 20)
        Me.dtpPickupLatestTime.TabIndex = 5
        '
        'lblPickupLatestTime
        '
        Me.lblPickupLatestTime.AutoSize = True
        Me.lblPickupLatestTime.Location = New System.Drawing.Point(6, 43)
        Me.lblPickupLatestTime.Name = "lblPickupLatestTime"
        Me.lblPickupLatestTime.Size = New System.Drawing.Size(65, 13)
        Me.lblPickupLatestTime.TabIndex = 4
        Me.lblPickupLatestTime.Text = "Latest Time:"
        '
        'lblPickupReadyTime
        '
        Me.lblPickupReadyTime.AutoSize = True
        Me.lblPickupReadyTime.Location = New System.Drawing.Point(193, 17)
        Me.lblPickupReadyTime.Name = "lblPickupReadyTime"
        Me.lblPickupReadyTime.Size = New System.Drawing.Size(67, 13)
        Me.lblPickupReadyTime.TabIndex = 2
        Me.lblPickupReadyTime.Text = "Ready Time:"
        '
        'lblPickupDate
        '
        Me.lblPickupDate.AutoSize = True
        Me.lblPickupDate.Location = New System.Drawing.Point(6, 17)
        Me.lblPickupDate.Name = "lblPickupDate"
        Me.lblPickupDate.Size = New System.Drawing.Size(33, 13)
        Me.lblPickupDate.TabIndex = 0
        Me.lblPickupDate.Text = "Date:"
        '
        'dtpPickupReadyTime
        '
        Me.dtpPickupReadyTime.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpPickupReadyTime.Location = New System.Drawing.Point(266, 13)
        Me.dtpPickupReadyTime.Name = "dtpPickupReadyTime"
        Me.dtpPickupReadyTime.ShowUpDown = True
        Me.dtpPickupReadyTime.Size = New System.Drawing.Size(88, 20)
        Me.dtpPickupReadyTime.TabIndex = 3
        '
        'dtpPickupDate
        '
        Me.dtpPickupDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpPickupDate.Location = New System.Drawing.Point(99, 13)
        Me.dtpPickupDate.Name = "dtpPickupDate"
        Me.dtpPickupDate.Size = New System.Drawing.Size(88, 20)
        Me.dtpPickupDate.TabIndex = 1
        '
        'gcPickupVehicle
        '
        Me.gcPickupVehicle.Controls.Add(Me.lblPickupVehicle)
        Me.gcPickupVehicle.Controls.Add(Me.txtPickupVehicle)
        Me.gcPickupVehicle.Location = New System.Drawing.Point(6, 75)
        Me.gcPickupVehicle.Name = "gcPickupVehicle"
        Me.gcPickupVehicle.Size = New System.Drawing.Size(322, 37)
        Me.gcPickupVehicle.TabIndex = 1
        Me.gcPickupVehicle.TabStop = False
        Me.gcPickupVehicle.Text = "Vehicle"
        '
        'lblPickupVehicle
        '
        Me.lblPickupVehicle.AutoSize = True
        Me.lblPickupVehicle.Location = New System.Drawing.Point(6, 15)
        Me.lblPickupVehicle.Name = "lblPickupVehicle"
        Me.lblPickupVehicle.Size = New System.Drawing.Size(72, 13)
        Me.lblPickupVehicle.TabIndex = 0
        Me.lblPickupVehicle.Text = "Vehicle Type:"
        '
        'txtPickupVehicle
        '
        Me.txtPickupVehicle.Location = New System.Drawing.Point(99, 11)
        Me.txtPickupVehicle.Name = "txtPickupVehicle"
        Me.txtPickupVehicle.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupVehicle.TabIndex = 1
        '
        'gcPickupReferences
        '
        Me.gcPickupReferences.Controls.Add(Me.lblPickupReference2)
        Me.gcPickupReferences.Controls.Add(Me.lblPickupReference1)
        Me.gcPickupReferences.Controls.Add(Me.txtPickupReference2)
        Me.gcPickupReferences.Controls.Add(Me.txtPickupReference1)
        Me.gcPickupReferences.Location = New System.Drawing.Point(6, 6)
        Me.gcPickupReferences.Name = "gcPickupReferences"
        Me.gcPickupReferences.Size = New System.Drawing.Size(322, 70)
        Me.gcPickupReferences.TabIndex = 0
        Me.gcPickupReferences.TabStop = False
        Me.gcPickupReferences.Text = "References"
        '
        'lblPickupReference2
        '
        Me.lblPickupReference2.AutoSize = True
        Me.lblPickupReference2.Location = New System.Drawing.Point(6, 43)
        Me.lblPickupReference2.Name = "lblPickupReference2"
        Me.lblPickupReference2.Size = New System.Drawing.Size(66, 13)
        Me.lblPickupReference2.TabIndex = 2
        Me.lblPickupReference2.Text = "Reference2:"
        '
        'lblPickupReference1
        '
        Me.lblPickupReference1.AutoSize = True
        Me.lblPickupReference1.Location = New System.Drawing.Point(6, 17)
        Me.lblPickupReference1.Name = "lblPickupReference1"
        Me.lblPickupReference1.Size = New System.Drawing.Size(66, 13)
        Me.lblPickupReference1.TabIndex = 0
        Me.lblPickupReference1.Text = "Reference1:"
        '
        'txtPickupReference2
        '
        Me.txtPickupReference2.Location = New System.Drawing.Point(99, 39)
        Me.txtPickupReference2.Name = "txtPickupReference2"
        Me.txtPickupReference2.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupReference2.TabIndex = 3
        '
        'txtPickupReference1
        '
        Me.txtPickupReference1.Location = New System.Drawing.Point(99, 13)
        Me.txtPickupReference1.Name = "txtPickupReference1"
        Me.txtPickupReference1.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupReference1.TabIndex = 1
        '
        'gcPickupAddress
        '
        Me.gcPickupAddress.Controls.Add(Me.lblPickupLocation)
        Me.gcPickupAddress.Controls.Add(Me.txtPickupLocation)
        Me.gcPickupAddress.Controls.Add(Me.lblPickupAddressCountry)
        Me.gcPickupAddress.Controls.Add(Me.lblPickupAddressPostCode)
        Me.gcPickupAddress.Controls.Add(Me.lblPickupAddressState)
        Me.gcPickupAddress.Controls.Add(Me.lblPickupAddressCity)
        Me.gcPickupAddress.Controls.Add(Me.lblPickupAddressLine3)
        Me.gcPickupAddress.Controls.Add(Me.lblPickupAddressLine2)
        Me.gcPickupAddress.Controls.Add(Me.lblPickupAddressLine1)
        Me.gcPickupAddress.Controls.Add(Me.txtPickupAddressCountry)
        Me.gcPickupAddress.Controls.Add(Me.txtPickupAddressPostCode)
        Me.gcPickupAddress.Controls.Add(Me.txtPickupAddressState)
        Me.gcPickupAddress.Controls.Add(Me.txtPickupAddressCity)
        Me.gcPickupAddress.Controls.Add(Me.txtPickupAddressLine3)
        Me.gcPickupAddress.Controls.Add(Me.txtPickupAddressLine2)
        Me.gcPickupAddress.Controls.Add(Me.txtPickupAddressLine1)
        Me.gcPickupAddress.Location = New System.Drawing.Point(6, 115)
        Me.gcPickupAddress.Name = "gcPickupAddress"
        Me.gcPickupAddress.Size = New System.Drawing.Size(322, 231)
        Me.gcPickupAddress.TabIndex = 2
        Me.gcPickupAddress.TabStop = False
        Me.gcPickupAddress.Text = "Address"
        '
        'lblPickupLocation
        '
        Me.lblPickupLocation.AutoSize = True
        Me.lblPickupLocation.Location = New System.Drawing.Point(6, 205)
        Me.lblPickupLocation.Name = "lblPickupLocation"
        Me.lblPickupLocation.Size = New System.Drawing.Size(51, 13)
        Me.lblPickupLocation.TabIndex = 14
        Me.lblPickupLocation.Text = "Location:"
        '
        'txtPickupLocation
        '
        Me.txtPickupLocation.Location = New System.Drawing.Point(99, 201)
        Me.txtPickupLocation.Name = "txtPickupLocation"
        Me.txtPickupLocation.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupLocation.TabIndex = 15
        '
        'lblPickupAddressCountry
        '
        Me.lblPickupAddressCountry.AutoSize = True
        Me.lblPickupAddressCountry.Location = New System.Drawing.Point(6, 179)
        Me.lblPickupAddressCountry.Name = "lblPickupAddressCountry"
        Me.lblPickupAddressCountry.Size = New System.Drawing.Size(46, 13)
        Me.lblPickupAddressCountry.TabIndex = 12
        Me.lblPickupAddressCountry.Text = "Country:"
        '
        'lblPickupAddressPostCode
        '
        Me.lblPickupAddressPostCode.AutoSize = True
        Me.lblPickupAddressPostCode.Location = New System.Drawing.Point(6, 153)
        Me.lblPickupAddressPostCode.Name = "lblPickupAddressPostCode"
        Me.lblPickupAddressPostCode.Size = New System.Drawing.Size(59, 13)
        Me.lblPickupAddressPostCode.TabIndex = 10
        Me.lblPickupAddressPostCode.Text = "Post Code:"
        '
        'lblPickupAddressState
        '
        Me.lblPickupAddressState.AutoSize = True
        Me.lblPickupAddressState.Location = New System.Drawing.Point(6, 127)
        Me.lblPickupAddressState.Name = "lblPickupAddressState"
        Me.lblPickupAddressState.Size = New System.Drawing.Size(35, 13)
        Me.lblPickupAddressState.TabIndex = 8
        Me.lblPickupAddressState.Text = "State:"
        '
        'lblPickupAddressCity
        '
        Me.lblPickupAddressCity.AutoSize = True
        Me.lblPickupAddressCity.Location = New System.Drawing.Point(6, 101)
        Me.lblPickupAddressCity.Name = "lblPickupAddressCity"
        Me.lblPickupAddressCity.Size = New System.Drawing.Size(27, 13)
        Me.lblPickupAddressCity.TabIndex = 6
        Me.lblPickupAddressCity.Text = "City:"
        '
        'lblPickupAddressLine3
        '
        Me.lblPickupAddressLine3.AutoSize = True
        Me.lblPickupAddressLine3.Location = New System.Drawing.Point(6, 75)
        Me.lblPickupAddressLine3.Name = "lblPickupAddressLine3"
        Me.lblPickupAddressLine3.Size = New System.Drawing.Size(36, 13)
        Me.lblPickupAddressLine3.TabIndex = 4
        Me.lblPickupAddressLine3.Text = "Line3:"
        '
        'lblPickupAddressLine2
        '
        Me.lblPickupAddressLine2.AutoSize = True
        Me.lblPickupAddressLine2.Location = New System.Drawing.Point(6, 49)
        Me.lblPickupAddressLine2.Name = "lblPickupAddressLine2"
        Me.lblPickupAddressLine2.Size = New System.Drawing.Size(36, 13)
        Me.lblPickupAddressLine2.TabIndex = 2
        Me.lblPickupAddressLine2.Text = "Line2:"
        '
        'lblPickupAddressLine1
        '
        Me.lblPickupAddressLine1.AutoSize = True
        Me.lblPickupAddressLine1.Location = New System.Drawing.Point(6, 23)
        Me.lblPickupAddressLine1.Name = "lblPickupAddressLine1"
        Me.lblPickupAddressLine1.Size = New System.Drawing.Size(36, 13)
        Me.lblPickupAddressLine1.TabIndex = 0
        Me.lblPickupAddressLine1.Text = "Line1:"
        '
        'txtPickupAddressCountry
        '
        Me.txtPickupAddressCountry.Location = New System.Drawing.Point(99, 175)
        Me.txtPickupAddressCountry.Name = "txtPickupAddressCountry"
        Me.txtPickupAddressCountry.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupAddressCountry.TabIndex = 13
        '
        'txtPickupAddressPostCode
        '
        Me.txtPickupAddressPostCode.Location = New System.Drawing.Point(99, 149)
        Me.txtPickupAddressPostCode.Name = "txtPickupAddressPostCode"
        Me.txtPickupAddressPostCode.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupAddressPostCode.TabIndex = 11
        '
        'txtPickupAddressState
        '
        Me.txtPickupAddressState.Location = New System.Drawing.Point(99, 123)
        Me.txtPickupAddressState.Name = "txtPickupAddressState"
        Me.txtPickupAddressState.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupAddressState.TabIndex = 9
        '
        'txtPickupAddressCity
        '
        Me.txtPickupAddressCity.Location = New System.Drawing.Point(99, 97)
        Me.txtPickupAddressCity.Name = "txtPickupAddressCity"
        Me.txtPickupAddressCity.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupAddressCity.TabIndex = 7
        '
        'txtPickupAddressLine3
        '
        Me.txtPickupAddressLine3.Location = New System.Drawing.Point(99, 71)
        Me.txtPickupAddressLine3.Name = "txtPickupAddressLine3"
        Me.txtPickupAddressLine3.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupAddressLine3.TabIndex = 5
        '
        'txtPickupAddressLine2
        '
        Me.txtPickupAddressLine2.Location = New System.Drawing.Point(99, 45)
        Me.txtPickupAddressLine2.Name = "txtPickupAddressLine2"
        Me.txtPickupAddressLine2.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupAddressLine2.TabIndex = 3
        '
        'txtPickupAddressLine1
        '
        Me.txtPickupAddressLine1.Location = New System.Drawing.Point(99, 19)
        Me.txtPickupAddressLine1.Name = "txtPickupAddressLine1"
        Me.txtPickupAddressLine1.Size = New System.Drawing.Size(217, 20)
        Me.txtPickupAddressLine1.TabIndex = 1
        '
        'tpPickupItems
        '
        Me.tpPickupItems.Controls.Add(Me.gcShipmentDetailsTypes)
        Me.tpPickupItems.Location = New System.Drawing.Point(4, 22)
        Me.tpPickupItems.Name = "tpPickupItems"
        Me.tpPickupItems.Size = New System.Drawing.Size(780, 391)
        Me.tpPickupItems.TabIndex = 3
        Me.tpPickupItems.Text = "Pickup Items"
        Me.tpPickupItems.UseVisualStyleBackColor = True
        '
        'gcShipmentDetailsTypes
        '
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailComments)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailNumberOfPieces)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lvPickupItems)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.btnPickupDetailDelete)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.btnPickupDetailAdd)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.txtPickupItemDetailComments)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.gcPickupItemDetailDimensions)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.nudPickupItemDetailExtraCharges)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailExtraCharges)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.txtPickupItemDetailExtraChargesCurrency)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.nudPickupItemDetailCashAmount)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailCashAmount)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.txtPickupItemDetailCashAmountCurrency)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailVolume)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailVolumeUnit)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.cmbPickupItemDetailVolumeUnit)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.nudPickupItemDetailVolume)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailWeight)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailWeightUnit)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.cmbPickupItemDetailWeightUnit)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.nudPickupItemDetailWeight)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailPackageType)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.txtPickupItemDetailPackageType)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.nudPickupItemDetailNumberOfPieces)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailNumberOfShipments)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.nudPickupItemDetailNumberOfShipments)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailPaymentType)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailProductType)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.lblPickupItemDetailProductGroup)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.txtPickupItemDetailPaymentType)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.txtPickupItemDetailProductType)
        Me.gcShipmentDetailsTypes.Controls.Add(Me.txtPickupItemDetailProductGroup)
        Me.gcShipmentDetailsTypes.Location = New System.Drawing.Point(6, 6)
        Me.gcShipmentDetailsTypes.Name = "gcShipmentDetailsTypes"
        Me.gcShipmentDetailsTypes.Size = New System.Drawing.Size(769, 382)
        Me.gcShipmentDetailsTypes.TabIndex = 3
        Me.gcShipmentDetailsTypes.TabStop = False
        Me.gcShipmentDetailsTypes.Text = "Details"
        '
        'lblPickupItemDetailComments
        '
        Me.lblPickupItemDetailComments.AutoSize = True
        Me.lblPickupItemDetailComments.Location = New System.Drawing.Point(350, 175)
        Me.lblPickupItemDetailComments.Name = "lblPickupItemDetailComments"
        Me.lblPickupItemDetailComments.Size = New System.Drawing.Size(59, 13)
        Me.lblPickupItemDetailComments.TabIndex = 27
        Me.lblPickupItemDetailComments.Text = "Comments:"
        '
        'lblPickupItemDetailNumberOfPieces
        '
        Me.lblPickupItemDetailNumberOfPieces.AutoSize = True
        Me.lblPickupItemDetailNumberOfPieces.Location = New System.Drawing.Point(350, 73)
        Me.lblPickupItemDetailNumberOfPieces.Name = "lblPickupItemDetailNumberOfPieces"
        Me.lblPickupItemDetailNumberOfPieces.Size = New System.Drawing.Size(74, 13)
        Me.lblPickupItemDetailNumberOfPieces.TabIndex = 10
        Me.lblPickupItemDetailNumberOfPieces.Text = "No. of Pieces:"
        '
        'lvPickupItems
        '
        Me.lvPickupItems.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colProductGroup, Me.colProductType, Me.colPaymentType, Me.colPackageType, Me.colNumberOfShipments, Me.colNumberOfPieces, Me.colWeight, Me.colVolume, Me.colCashAmount, Me.colExtraCharges, Me.colDimensions, Me.colComments})
        Me.lvPickupItems.FullRowSelect = True
        Me.lvPickupItems.GridLines = True
        Me.lvPickupItems.Location = New System.Drawing.Point(11, 252)
        Me.lvPickupItems.MultiSelect = False
        Me.lvPickupItems.Name = "lvPickupItems"
        Me.lvPickupItems.Size = New System.Drawing.Size(754, 124)
        Me.lvPickupItems.TabIndex = 41
        Me.lvPickupItems.UseCompatibleStateImageBehavior = False
        Me.lvPickupItems.View = System.Windows.Forms.View.Details
        '
        'colProductGroup
        '
        Me.colProductGroup.Text = "Product Group"
        '
        'colProductType
        '
        Me.colProductType.Text = "Product Type"
        '
        'colPaymentType
        '
        Me.colPaymentType.Text = "Payment Type"
        '
        'colPackageType
        '
        Me.colPackageType.Text = "Package Type"
        Me.colPackageType.Width = 101
        '
        'colNumberOfShipments
        '
        Me.colNumberOfShipments.Text = "No. of Shipments"
        Me.colNumberOfShipments.Width = 80
        '
        'colNumberOfPieces
        '
        Me.colNumberOfPieces.Text = "No. of Pieces"
        '
        'colWeight
        '
        Me.colWeight.Text = "Weight"
        '
        'colVolume
        '
        Me.colVolume.Text = "Volume"
        '
        'colCashAmount
        '
        Me.colCashAmount.Text = "Cash Amount"
        '
        'colExtraCharges
        '
        Me.colExtraCharges.Text = "Extra Charges"
        '
        'colDimensions
        '
        Me.colDimensions.Text = "Dimensions"
        '
        'colComments
        '
        Me.colComments.Text = "Comments"
        '
        'btnPickupDetailDelete
        '
        Me.btnPickupDetailDelete.Location = New System.Drawing.Point(690, 223)
        Me.btnPickupDetailDelete.Name = "btnPickupDetailDelete"
        Me.btnPickupDetailDelete.Size = New System.Drawing.Size(75, 23)
        Me.btnPickupDetailDelete.TabIndex = 30
        Me.btnPickupDetailDelete.Text = "Remove"
        Me.btnPickupDetailDelete.UseVisualStyleBackColor = True
        '
        'btnPickupDetailAdd
        '
        Me.btnPickupDetailAdd.Location = New System.Drawing.Point(609, 223)
        Me.btnPickupDetailAdd.Name = "btnPickupDetailAdd"
        Me.btnPickupDetailAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnPickupDetailAdd.TabIndex = 29
        Me.btnPickupDetailAdd.Text = "Add"
        Me.btnPickupDetailAdd.UseVisualStyleBackColor = True
        '
        'txtPickupItemDetailComments
        '
        Me.txtPickupItemDetailComments.Location = New System.Drawing.Point(446, 142)
        Me.txtPickupItemDetailComments.Multiline = True
        Me.txtPickupItemDetailComments.Name = "txtPickupItemDetailComments"
        Me.txtPickupItemDetailComments.Size = New System.Drawing.Size(216, 78)
        Me.txtPickupItemDetailComments.TabIndex = 28
        '
        'gcPickupItemDetailDimensions
        '
        Me.gcPickupItemDetailDimensions.Controls.Add(Me.lblPickupItemDetailUnit)
        Me.gcPickupItemDetailDimensions.Controls.Add(Me.lblPickupItemDetailWidth)
        Me.gcPickupItemDetailDimensions.Controls.Add(Me.lblPickupItemDetailHeight)
        Me.gcPickupItemDetailDimensions.Controls.Add(Me.lblPickupItemDetailLength)
        Me.gcPickupItemDetailDimensions.Controls.Add(Me.cmbPickupItemDetailUnit)
        Me.gcPickupItemDetailDimensions.Controls.Add(Me.nudPickupItemDetailWidth)
        Me.gcPickupItemDetailDimensions.Controls.Add(Me.nudPickupItemDetailHeight)
        Me.gcPickupItemDetailDimensions.Controls.Add(Me.nudPickupItemDetailLength)
        Me.gcPickupItemDetailDimensions.Location = New System.Drawing.Point(11, 142)
        Me.gcPickupItemDetailDimensions.Name = "gcPickupItemDetailDimensions"
        Me.gcPickupItemDetailDimensions.Size = New System.Drawing.Size(304, 78)
        Me.gcPickupItemDetailDimensions.TabIndex = 26
        Me.gcPickupItemDetailDimensions.TabStop = False
        Me.gcPickupItemDetailDimensions.Text = "Dimensions"
        '
        'lblPickupItemDetailUnit
        '
        Me.lblPickupItemDetailUnit.AutoSize = True
        Me.lblPickupItemDetailUnit.Location = New System.Drawing.Point(168, 49)
        Me.lblPickupItemDetailUnit.Name = "lblPickupItemDetailUnit"
        Me.lblPickupItemDetailUnit.Size = New System.Drawing.Size(29, 13)
        Me.lblPickupItemDetailUnit.TabIndex = 6
        Me.lblPickupItemDetailUnit.Text = "Unit:"
        '
        'lblPickupItemDetailWidth
        '
        Me.lblPickupItemDetailWidth.AutoSize = True
        Me.lblPickupItemDetailWidth.Location = New System.Drawing.Point(168, 23)
        Me.lblPickupItemDetailWidth.Name = "lblPickupItemDetailWidth"
        Me.lblPickupItemDetailWidth.Size = New System.Drawing.Size(38, 13)
        Me.lblPickupItemDetailWidth.TabIndex = 2
        Me.lblPickupItemDetailWidth.Text = "Width:"
        '
        'lblPickupItemDetailHeight
        '
        Me.lblPickupItemDetailHeight.AutoSize = True
        Me.lblPickupItemDetailHeight.Location = New System.Drawing.Point(8, 49)
        Me.lblPickupItemDetailHeight.Name = "lblPickupItemDetailHeight"
        Me.lblPickupItemDetailHeight.Size = New System.Drawing.Size(41, 13)
        Me.lblPickupItemDetailHeight.TabIndex = 4
        Me.lblPickupItemDetailHeight.Text = "Height:"
        '
        'lblPickupItemDetailLength
        '
        Me.lblPickupItemDetailLength.AutoSize = True
        Me.lblPickupItemDetailLength.Location = New System.Drawing.Point(6, 23)
        Me.lblPickupItemDetailLength.Name = "lblPickupItemDetailLength"
        Me.lblPickupItemDetailLength.Size = New System.Drawing.Size(43, 13)
        Me.lblPickupItemDetailLength.TabIndex = 0
        Me.lblPickupItemDetailLength.Text = "Length:"
        '
        'cmbPickupItemDetailUnit
        '
        Me.cmbPickupItemDetailUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPickupItemDetailUnit.FormattingEnabled = True
        Me.cmbPickupItemDetailUnit.Items.AddRange(New Object() {"cm", "m"})
        Me.cmbPickupItemDetailUnit.Location = New System.Drawing.Point(213, 42)
        Me.cmbPickupItemDetailUnit.Name = "cmbPickupItemDetailUnit"
        Me.cmbPickupItemDetailUnit.Size = New System.Drawing.Size(62, 21)
        Me.cmbPickupItemDetailUnit.TabIndex = 7
        '
        'nudPickupItemDetailWidth
        '
        Me.nudPickupItemDetailWidth.DecimalPlaces = 2
        Me.nudPickupItemDetailWidth.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.nudPickupItemDetailWidth.Location = New System.Drawing.Point(212, 19)
        Me.nudPickupItemDetailWidth.Name = "nudPickupItemDetailWidth"
        Me.nudPickupItemDetailWidth.Size = New System.Drawing.Size(63, 20)
        Me.nudPickupItemDetailWidth.TabIndex = 3
        '
        'nudPickupItemDetailHeight
        '
        Me.nudPickupItemDetailHeight.DecimalPlaces = 2
        Me.nudPickupItemDetailHeight.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.nudPickupItemDetailHeight.Location = New System.Drawing.Point(88, 42)
        Me.nudPickupItemDetailHeight.Name = "nudPickupItemDetailHeight"
        Me.nudPickupItemDetailHeight.Size = New System.Drawing.Size(63, 20)
        Me.nudPickupItemDetailHeight.TabIndex = 5
        '
        'nudPickupItemDetailLength
        '
        Me.nudPickupItemDetailLength.DecimalPlaces = 2
        Me.nudPickupItemDetailLength.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.nudPickupItemDetailLength.Location = New System.Drawing.Point(88, 19)
        Me.nudPickupItemDetailLength.Name = "nudPickupItemDetailLength"
        Me.nudPickupItemDetailLength.Size = New System.Drawing.Size(63, 20)
        Me.nudPickupItemDetailLength.TabIndex = 1
        '
        'nudPickupItemDetailExtraCharges
        '
        Me.nudPickupItemDetailExtraCharges.DecimalPlaces = 3
        Me.nudPickupItemDetailExtraCharges.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudPickupItemDetailExtraCharges.Location = New System.Drawing.Point(446, 119)
        Me.nudPickupItemDetailExtraCharges.Name = "nudPickupItemDetailExtraCharges"
        Me.nudPickupItemDetailExtraCharges.Size = New System.Drawing.Size(100, 20)
        Me.nudPickupItemDetailExtraCharges.TabIndex = 24
        '
        'lblPickupItemDetailExtraCharges
        '
        Me.lblPickupItemDetailExtraCharges.AutoSize = True
        Me.lblPickupItemDetailExtraCharges.Location = New System.Drawing.Point(350, 123)
        Me.lblPickupItemDetailExtraCharges.Name = "lblPickupItemDetailExtraCharges"
        Me.lblPickupItemDetailExtraCharges.Size = New System.Drawing.Size(76, 13)
        Me.lblPickupItemDetailExtraCharges.TabIndex = 23
        Me.lblPickupItemDetailExtraCharges.Text = "Extra Charges:"
        '
        'txtPickupItemDetailExtraChargesCurrency
        '
        Me.txtPickupItemDetailExtraChargesCurrency.Location = New System.Drawing.Point(552, 118)
        Me.txtPickupItemDetailExtraChargesCurrency.Name = "txtPickupItemDetailExtraChargesCurrency"
        Me.txtPickupItemDetailExtraChargesCurrency.Size = New System.Drawing.Size(110, 20)
        Me.txtPickupItemDetailExtraChargesCurrency.TabIndex = 25
        '
        'nudPickupItemDetailCashAmount
        '
        Me.nudPickupItemDetailCashAmount.DecimalPlaces = 3
        Me.nudPickupItemDetailCashAmount.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudPickupItemDetailCashAmount.Location = New System.Drawing.Point(99, 119)
        Me.nudPickupItemDetailCashAmount.Name = "nudPickupItemDetailCashAmount"
        Me.nudPickupItemDetailCashAmount.Size = New System.Drawing.Size(100, 20)
        Me.nudPickupItemDetailCashAmount.TabIndex = 21
        '
        'lblPickupItemDetailCashAmount
        '
        Me.lblPickupItemDetailCashAmount.AutoSize = True
        Me.lblPickupItemDetailCashAmount.Location = New System.Drawing.Point(4, 123)
        Me.lblPickupItemDetailCashAmount.Name = "lblPickupItemDetailCashAmount"
        Me.lblPickupItemDetailCashAmount.Size = New System.Drawing.Size(73, 13)
        Me.lblPickupItemDetailCashAmount.TabIndex = 20
        Me.lblPickupItemDetailCashAmount.Text = "Cash Amount:"
        '
        'txtPickupItemDetailCashAmountCurrency
        '
        Me.txtPickupItemDetailCashAmountCurrency.Location = New System.Drawing.Point(205, 119)
        Me.txtPickupItemDetailCashAmountCurrency.Name = "txtPickupItemDetailCashAmountCurrency"
        Me.txtPickupItemDetailCashAmountCurrency.Size = New System.Drawing.Size(110, 20)
        Me.txtPickupItemDetailCashAmountCurrency.TabIndex = 22
        '
        'lblPickupItemDetailVolume
        '
        Me.lblPickupItemDetailVolume.AutoSize = True
        Me.lblPickupItemDetailVolume.Location = New System.Drawing.Point(350, 98)
        Me.lblPickupItemDetailVolume.Name = "lblPickupItemDetailVolume"
        Me.lblPickupItemDetailVolume.Size = New System.Drawing.Size(45, 13)
        Me.lblPickupItemDetailVolume.TabIndex = 16
        Me.lblPickupItemDetailVolume.Text = "Volume:"
        '
        'lblPickupItemDetailVolumeUnit
        '
        Me.lblPickupItemDetailVolumeUnit.AutoSize = True
        Me.lblPickupItemDetailVolumeUnit.Location = New System.Drawing.Point(515, 97)
        Me.lblPickupItemDetailVolumeUnit.Name = "lblPickupItemDetailVolumeUnit"
        Me.lblPickupItemDetailVolumeUnit.Size = New System.Drawing.Size(29, 13)
        Me.lblPickupItemDetailVolumeUnit.TabIndex = 18
        Me.lblPickupItemDetailVolumeUnit.Text = "Unit:"
        '
        'cmbPickupItemDetailVolumeUnit
        '
        Me.cmbPickupItemDetailVolumeUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPickupItemDetailVolumeUnit.FormattingEnabled = True
        Me.cmbPickupItemDetailVolumeUnit.Items.AddRange(New Object() {"cm3", "inch3"})
        Me.cmbPickupItemDetailVolumeUnit.Location = New System.Drawing.Point(552, 93)
        Me.cmbPickupItemDetailVolumeUnit.Name = "cmbPickupItemDetailVolumeUnit"
        Me.cmbPickupItemDetailVolumeUnit.Size = New System.Drawing.Size(110, 21)
        Me.cmbPickupItemDetailVolumeUnit.TabIndex = 19
        '
        'nudPickupItemDetailVolume
        '
        Me.nudPickupItemDetailVolume.DecimalPlaces = 3
        Me.nudPickupItemDetailVolume.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudPickupItemDetailVolume.Location = New System.Drawing.Point(446, 94)
        Me.nudPickupItemDetailVolume.Name = "nudPickupItemDetailVolume"
        Me.nudPickupItemDetailVolume.Size = New System.Drawing.Size(63, 20)
        Me.nudPickupItemDetailVolume.TabIndex = 17
        '
        'lblPickupItemDetailWeight
        '
        Me.lblPickupItemDetailWeight.AutoSize = True
        Me.lblPickupItemDetailWeight.Location = New System.Drawing.Point(4, 98)
        Me.lblPickupItemDetailWeight.Name = "lblPickupItemDetailWeight"
        Me.lblPickupItemDetailWeight.Size = New System.Drawing.Size(44, 13)
        Me.lblPickupItemDetailWeight.TabIndex = 12
        Me.lblPickupItemDetailWeight.Text = "Weight:"
        '
        'lblPickupItemDetailWeightUnit
        '
        Me.lblPickupItemDetailWeightUnit.AutoSize = True
        Me.lblPickupItemDetailWeightUnit.Location = New System.Drawing.Point(168, 98)
        Me.lblPickupItemDetailWeightUnit.Name = "lblPickupItemDetailWeightUnit"
        Me.lblPickupItemDetailWeightUnit.Size = New System.Drawing.Size(29, 13)
        Me.lblPickupItemDetailWeightUnit.TabIndex = 14
        Me.lblPickupItemDetailWeightUnit.Text = "Unit:"
        '
        'cmbPickupItemDetailWeightUnit
        '
        Me.cmbPickupItemDetailWeightUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbPickupItemDetailWeightUnit.FormattingEnabled = True
        Me.cmbPickupItemDetailWeightUnit.Items.AddRange(New Object() {"KG", "LB"})
        Me.cmbPickupItemDetailWeightUnit.Location = New System.Drawing.Point(205, 94)
        Me.cmbPickupItemDetailWeightUnit.Name = "cmbPickupItemDetailWeightUnit"
        Me.cmbPickupItemDetailWeightUnit.Size = New System.Drawing.Size(110, 21)
        Me.cmbPickupItemDetailWeightUnit.TabIndex = 15
        '
        'nudPickupItemDetailWeight
        '
        Me.nudPickupItemDetailWeight.DecimalPlaces = 3
        Me.nudPickupItemDetailWeight.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.nudPickupItemDetailWeight.Location = New System.Drawing.Point(99, 94)
        Me.nudPickupItemDetailWeight.Name = "nudPickupItemDetailWeight"
        Me.nudPickupItemDetailWeight.Size = New System.Drawing.Size(63, 20)
        Me.nudPickupItemDetailWeight.TabIndex = 13
        '
        'lblPickupItemDetailPackageType
        '
        Me.lblPickupItemDetailPackageType.AutoSize = True
        Me.lblPickupItemDetailPackageType.Location = New System.Drawing.Point(350, 48)
        Me.lblPickupItemDetailPackageType.Name = "lblPickupItemDetailPackageType"
        Me.lblPickupItemDetailPackageType.Size = New System.Drawing.Size(80, 13)
        Me.lblPickupItemDetailPackageType.TabIndex = 6
        Me.lblPickupItemDetailPackageType.Text = "Package Type:"
        '
        'txtPickupItemDetailPackageType
        '
        Me.txtPickupItemDetailPackageType.Location = New System.Drawing.Point(446, 44)
        Me.txtPickupItemDetailPackageType.Name = "txtPickupItemDetailPackageType"
        Me.txtPickupItemDetailPackageType.Size = New System.Drawing.Size(216, 20)
        Me.txtPickupItemDetailPackageType.TabIndex = 7
        '
        'nudPickupItemDetailNumberOfPieces
        '
        Me.nudPickupItemDetailNumberOfPieces.Location = New System.Drawing.Point(446, 69)
        Me.nudPickupItemDetailNumberOfPieces.Name = "nudPickupItemDetailNumberOfPieces"
        Me.nudPickupItemDetailNumberOfPieces.Size = New System.Drawing.Size(216, 20)
        Me.nudPickupItemDetailNumberOfPieces.TabIndex = 11
        '
        'lblPickupItemDetailNumberOfShipments
        '
        Me.lblPickupItemDetailNumberOfShipments.AutoSize = True
        Me.lblPickupItemDetailNumberOfShipments.Location = New System.Drawing.Point(4, 73)
        Me.lblPickupItemDetailNumberOfShipments.Name = "lblPickupItemDetailNumberOfShipments"
        Me.lblPickupItemDetailNumberOfShipments.Size = New System.Drawing.Size(91, 13)
        Me.lblPickupItemDetailNumberOfShipments.TabIndex = 8
        Me.lblPickupItemDetailNumberOfShipments.Text = "No. of Shipments:"
        '
        'nudPickupItemDetailNumberOfShipments
        '
        Me.nudPickupItemDetailNumberOfShipments.Location = New System.Drawing.Point(99, 69)
        Me.nudPickupItemDetailNumberOfShipments.Name = "nudPickupItemDetailNumberOfShipments"
        Me.nudPickupItemDetailNumberOfShipments.Size = New System.Drawing.Size(216, 20)
        Me.nudPickupItemDetailNumberOfShipments.TabIndex = 9
        '
        'lblPickupItemDetailPaymentType
        '
        Me.lblPickupItemDetailPaymentType.AutoSize = True
        Me.lblPickupItemDetailPaymentType.Location = New System.Drawing.Point(4, 48)
        Me.lblPickupItemDetailPaymentType.Name = "lblPickupItemDetailPaymentType"
        Me.lblPickupItemDetailPaymentType.Size = New System.Drawing.Size(78, 13)
        Me.lblPickupItemDetailPaymentType.TabIndex = 4
        Me.lblPickupItemDetailPaymentType.Text = "Payment Type:"
        '
        'lblPickupItemDetailProductType
        '
        Me.lblPickupItemDetailProductType.AutoSize = True
        Me.lblPickupItemDetailProductType.Location = New System.Drawing.Point(350, 23)
        Me.lblPickupItemDetailProductType.Name = "lblPickupItemDetailProductType"
        Me.lblPickupItemDetailProductType.Size = New System.Drawing.Size(74, 13)
        Me.lblPickupItemDetailProductType.TabIndex = 2
        Me.lblPickupItemDetailProductType.Text = "Product Type:"
        '
        'lblPickupItemDetailProductGroup
        '
        Me.lblPickupItemDetailProductGroup.AutoSize = True
        Me.lblPickupItemDetailProductGroup.Location = New System.Drawing.Point(4, 23)
        Me.lblPickupItemDetailProductGroup.Name = "lblPickupItemDetailProductGroup"
        Me.lblPickupItemDetailProductGroup.Size = New System.Drawing.Size(79, 13)
        Me.lblPickupItemDetailProductGroup.TabIndex = 0
        Me.lblPickupItemDetailProductGroup.Text = "Product Group:"
        '
        'txtPickupItemDetailPaymentType
        '
        Me.txtPickupItemDetailPaymentType.Location = New System.Drawing.Point(99, 44)
        Me.txtPickupItemDetailPaymentType.Name = "txtPickupItemDetailPaymentType"
        Me.txtPickupItemDetailPaymentType.Size = New System.Drawing.Size(216, 20)
        Me.txtPickupItemDetailPaymentType.TabIndex = 5
        '
        'txtPickupItemDetailProductType
        '
        Me.txtPickupItemDetailProductType.Location = New System.Drawing.Point(446, 19)
        Me.txtPickupItemDetailProductType.Name = "txtPickupItemDetailProductType"
        Me.txtPickupItemDetailProductType.Size = New System.Drawing.Size(216, 20)
        Me.txtPickupItemDetailProductType.TabIndex = 3
        '
        'txtPickupItemDetailProductGroup
        '
        Me.txtPickupItemDetailProductGroup.Location = New System.Drawing.Point(99, 19)
        Me.txtPickupItemDetailProductGroup.Name = "txtPickupItemDetailProductGroup"
        Me.txtPickupItemDetailProductGroup.Size = New System.Drawing.Size(216, 20)
        Me.txtPickupItemDetailProductGroup.TabIndex = 1
        '
        'gcActions
        '
        Me.gcActions.Controls.Add(Me.btnAddShipments)
        Me.gcActions.Controls.Add(Me.btnReset)
        Me.gcActions.Controls.Add(Me.btnSubmitRequest)
        Me.gcActions.Location = New System.Drawing.Point(812, 12)
        Me.gcActions.Name = "gcActions"
        Me.gcActions.Size = New System.Drawing.Size(152, 198)
        Me.gcActions.TabIndex = 4
        Me.gcActions.TabStop = False
        Me.gcActions.Text = "Actions"
        '
        'btnAddShipments
        '
        Me.btnAddShipments.Location = New System.Drawing.Point(6, 77)
        Me.btnAddShipments.Name = "btnAddShipments"
        Me.btnAddShipments.Size = New System.Drawing.Size(134, 23)
        Me.btnAddShipments.TabIndex = 2
        Me.btnAddShipments.Text = "Add Shipments"
        Me.btnAddShipments.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(6, 48)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(134, 23)
        Me.btnReset.TabIndex = 1
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnSubmitRequest
        '
        Me.btnSubmitRequest.Location = New System.Drawing.Point(6, 19)
        Me.btnSubmitRequest.Name = "btnSubmitRequest"
        Me.btnSubmitRequest.Size = New System.Drawing.Size(134, 23)
        Me.btnSubmitRequest.TabIndex = 0
        Me.btnSubmitRequest.Text = "Submit Request"
        Me.btnSubmitRequest.UseVisualStyleBackColor = True
        '
        'gcLabelInfo
        '
        Me.gcLabelInfo.Controls.Add(Me.rbReportAsFile)
        Me.gcLabelInfo.Controls.Add(Me.rbReportAsURL)
        Me.gcLabelInfo.Controls.Add(Me.lblReportID)
        Me.gcLabelInfo.Controls.Add(Me.nudReportID)
        Me.gcLabelInfo.Controls.Add(Me.chkbGenerateLabels)
        Me.gcLabelInfo.Location = New System.Drawing.Point(412, 158)
        Me.gcLabelInfo.Name = "gcLabelInfo"
        Me.gcLabelInfo.Size = New System.Drawing.Size(394, 51)
        Me.gcLabelInfo.TabIndex = 2
        Me.gcLabelInfo.TabStop = False
        Me.gcLabelInfo.Text = "Label(s)"
        '
        'rbReportAsFile
        '
        Me.rbReportAsFile.AutoSize = True
        Me.rbReportAsFile.Location = New System.Drawing.Point(239, 30)
        Me.rbReportAsFile.Name = "rbReportAsFile"
        Me.rbReportAsFile.Size = New System.Drawing.Size(90, 17)
        Me.rbReportAsFile.TabIndex = 3
        Me.rbReportAsFile.TabStop = True
        Me.rbReportAsFile.Text = "Report as File"
        Me.rbReportAsFile.UseVisualStyleBackColor = True
        '
        'rbReportAsURL
        '
        Me.rbReportAsURL.AutoSize = True
        Me.rbReportAsURL.Location = New System.Drawing.Point(239, 12)
        Me.rbReportAsURL.Name = "rbReportAsURL"
        Me.rbReportAsURL.Size = New System.Drawing.Size(96, 17)
        Me.rbReportAsURL.TabIndex = 2
        Me.rbReportAsURL.TabStop = True
        Me.rbReportAsURL.Text = "Report as URL"
        Me.rbReportAsURL.UseVisualStyleBackColor = True
        '
        'lblReportID
        '
        Me.lblReportID.AutoSize = True
        Me.lblReportID.Location = New System.Drawing.Point(115, 20)
        Me.lblReportID.Name = "lblReportID"
        Me.lblReportID.Size = New System.Drawing.Size(56, 13)
        Me.lblReportID.TabIndex = 13
        Me.lblReportID.Text = "Report ID:"
        '
        'nudReportID
        '
        Me.nudReportID.Location = New System.Drawing.Point(172, 16)
        Me.nudReportID.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudReportID.Name = "nudReportID"
        Me.nudReportID.Size = New System.Drawing.Size(61, 20)
        Me.nudReportID.TabIndex = 1
        Me.nudReportID.Value = New Decimal(New Integer() {9201, 0, 0, 0})
        '
        'chkbGenerateLabels
        '
        Me.chkbGenerateLabels.AutoSize = True
        Me.chkbGenerateLabels.Location = New System.Drawing.Point(9, 19)
        Me.chkbGenerateLabels.Name = "chkbGenerateLabels"
        Me.chkbGenerateLabels.Size = New System.Drawing.Size(100, 17)
        Me.chkbGenerateLabels.TabIndex = 0
        Me.chkbGenerateLabels.Text = "Generate labels"
        Me.chkbGenerateLabels.UseVisualStyleBackColor = True
        '
        'frmPickup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(976, 686)
        Me.Controls.Add(Me.gcLabelInfo)
        Me.Controls.Add(Me.gcActions)
        Me.Controls.Add(Me.gcPickup)
        Me.Controls.Add(Me.gcTransaction)
        Me.Controls.Add(Me.gcClientInfo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmPickup"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Shipping API - Shipping Client - Pickup Creation Service"
        Me.gcTransaction.ResumeLayout(False)
        Me.gcTransaction.PerformLayout()
        Me.gcClientInfo.ResumeLayout(False)
        Me.gcClientInfo.PerformLayout()
        Me.gcPickup.ResumeLayout(False)
        Me.tcShipment.ResumeLayout(False)
        Me.tpPickupAddress.ResumeLayout(False)
        Me.gcPickupStatus.ResumeLayout(False)
        Me.gcPickupStatus.PerformLayout()
        Me.gcPickupContact.ResumeLayout(False)
        Me.gcPickupContact.PerformLayout()
        Me.gcPickupDateTime.ResumeLayout(False)
        Me.gcPickupDateTime.PerformLayout()
        Me.gcPickupVehicle.ResumeLayout(False)
        Me.gcPickupVehicle.PerformLayout()
        Me.gcPickupReferences.ResumeLayout(False)
        Me.gcPickupReferences.PerformLayout()
        Me.gcPickupAddress.ResumeLayout(False)
        Me.gcPickupAddress.PerformLayout()
        Me.tpPickupItems.ResumeLayout(False)
        Me.gcShipmentDetailsTypes.ResumeLayout(False)
        Me.gcShipmentDetailsTypes.PerformLayout()
        Me.gcPickupItemDetailDimensions.ResumeLayout(False)
        Me.gcPickupItemDetailDimensions.PerformLayout()
        CType(Me.nudPickupItemDetailWidth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPickupItemDetailHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPickupItemDetailLength, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPickupItemDetailExtraCharges, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPickupItemDetailCashAmount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPickupItemDetailVolume, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPickupItemDetailWeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPickupItemDetailNumberOfPieces, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPickupItemDetailNumberOfShipments, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gcActions.ResumeLayout(False)
        Me.gcLabelInfo.ResumeLayout(False)
        Me.gcLabelInfo.PerformLayout()
        CType(Me.nudReportID, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gcTransaction As System.Windows.Forms.GroupBox
    Friend WithEvents lblReference5 As System.Windows.Forms.Label
    Friend WithEvents lblReference4 As System.Windows.Forms.Label
    Friend WithEvents lblReference3 As System.Windows.Forms.Label
    Friend WithEvents lblReference2 As System.Windows.Forms.Label
    Friend WithEvents lblReference1 As System.Windows.Forms.Label
    Friend WithEvents txtReference5 As System.Windows.Forms.TextBox
    Friend WithEvents txtReference4 As System.Windows.Forms.TextBox
    Friend WithEvents txtReference3 As System.Windows.Forms.TextBox
    Friend WithEvents txtReference2 As System.Windows.Forms.TextBox
    Friend WithEvents txtReference1 As System.Windows.Forms.TextBox
    Friend WithEvents gcClientInfo As System.Windows.Forms.GroupBox
    Friend WithEvents lblVersion As System.Windows.Forms.Label
    Friend WithEvents lblAccountEntity As System.Windows.Forms.Label
    Friend WithEvents lblAccountCountry As System.Windows.Forms.Label
    Friend WithEvents lblAccountPin As System.Windows.Forms.Label
    Friend WithEvents lblAccountNumber As System.Windows.Forms.Label
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents lblUsername As System.Windows.Forms.Label
    Friend WithEvents txtVersion As System.Windows.Forms.TextBox
    Friend WithEvents txtAccountEntity As System.Windows.Forms.TextBox
    Friend WithEvents txtAccountCountryCode As System.Windows.Forms.TextBox
    Friend WithEvents txtAccountPin As System.Windows.Forms.TextBox
    Friend WithEvents txtAccountNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents gcPickup As System.Windows.Forms.GroupBox
    Friend WithEvents tcShipment As System.Windows.Forms.TabControl
    Friend WithEvents tpPickupAddress As System.Windows.Forms.TabPage
    Friend WithEvents gcPickupAddress As System.Windows.Forms.GroupBox
    Friend WithEvents lblPickupAddressCountry As System.Windows.Forms.Label
    Friend WithEvents lblPickupAddressPostCode As System.Windows.Forms.Label
    Friend WithEvents lblPickupAddressState As System.Windows.Forms.Label
    Friend WithEvents lblPickupAddressCity As System.Windows.Forms.Label
    Friend WithEvents lblPickupAddressLine3 As System.Windows.Forms.Label
    Friend WithEvents lblPickupAddressLine2 As System.Windows.Forms.Label
    Friend WithEvents lblPickupAddressLine1 As System.Windows.Forms.Label
    Friend WithEvents txtPickupAddressCountry As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupAddressPostCode As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupAddressState As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupAddressCity As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupAddressLine3 As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupAddressLine2 As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupAddressLine1 As System.Windows.Forms.TextBox
    Friend WithEvents tpPickupItems As System.Windows.Forms.TabPage
    Friend WithEvents gcPickupReferences As System.Windows.Forms.GroupBox
    Friend WithEvents lblPickupReference2 As System.Windows.Forms.Label
    Friend WithEvents lblPickupReference1 As System.Windows.Forms.Label
    Friend WithEvents txtPickupReference2 As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupReference1 As System.Windows.Forms.TextBox
    Friend WithEvents lblPickupLocation As System.Windows.Forms.Label
    Friend WithEvents txtPickupLocation As System.Windows.Forms.TextBox
    Friend WithEvents gcPickupVehicle As System.Windows.Forms.GroupBox
    Friend WithEvents lblPickupVehicle As System.Windows.Forms.Label
    Friend WithEvents txtPickupVehicle As System.Windows.Forms.TextBox
    Friend WithEvents gcPickupDateTime As System.Windows.Forms.GroupBox
    Friend WithEvents lblPickupReadyTime As System.Windows.Forms.Label
    Friend WithEvents lblPickupDate As System.Windows.Forms.Label
    Friend WithEvents dtpPickupReadyTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpPickupDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblPickupClosingTime As System.Windows.Forms.Label
    Friend WithEvents dtpPickupClosingTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpPickupLatestTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblPickupLatestTime As System.Windows.Forms.Label
    Friend WithEvents lblPickupComments As System.Windows.Forms.Label
    Friend WithEvents txtPickupComments As System.Windows.Forms.TextBox
    Friend WithEvents gcActions As System.Windows.Forms.GroupBox
    Friend WithEvents btnReset As System.Windows.Forms.Button
    Friend WithEvents btnSubmitRequest As System.Windows.Forms.Button
    Friend WithEvents gcShipmentDetailsTypes As System.Windows.Forms.GroupBox
    Friend WithEvents lblPickupItemDetailPackageType As System.Windows.Forms.Label
    Friend WithEvents txtPickupItemDetailPackageType As System.Windows.Forms.TextBox
    Friend WithEvents nudPickupItemDetailNumberOfPieces As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblPickupItemDetailNumberOfShipments As System.Windows.Forms.Label
    Friend WithEvents nudPickupItemDetailNumberOfShipments As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblPickupItemDetailPaymentType As System.Windows.Forms.Label
    Friend WithEvents lblPickupItemDetailProductType As System.Windows.Forms.Label
    Friend WithEvents lblPickupItemDetailProductGroup As System.Windows.Forms.Label
    Friend WithEvents txtPickupItemDetailPaymentType As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupItemDetailProductType As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupItemDetailProductGroup As System.Windows.Forms.TextBox
    Friend WithEvents lvPickupItems As System.Windows.Forms.ListView
    Friend WithEvents colProductGroup As System.Windows.Forms.ColumnHeader
    Friend WithEvents colProductType As System.Windows.Forms.ColumnHeader
    Friend WithEvents colPaymentType As System.Windows.Forms.ColumnHeader
    Friend WithEvents colPackageType As System.Windows.Forms.ColumnHeader
    Friend WithEvents colNumberOfShipments As System.Windows.Forms.ColumnHeader
    Friend WithEvents btnPickupDetailDelete As System.Windows.Forms.Button
    Friend WithEvents btnPickupDetailAdd As System.Windows.Forms.Button
    Friend WithEvents txtPickupItemDetailComments As System.Windows.Forms.TextBox
    Friend WithEvents gcPickupItemDetailDimensions As System.Windows.Forms.GroupBox
    Friend WithEvents lblPickupItemDetailUnit As System.Windows.Forms.Label
    Friend WithEvents lblPickupItemDetailWidth As System.Windows.Forms.Label
    Friend WithEvents lblPickupItemDetailHeight As System.Windows.Forms.Label
    Friend WithEvents lblPickupItemDetailLength As System.Windows.Forms.Label
    Friend WithEvents cmbPickupItemDetailUnit As System.Windows.Forms.ComboBox
    Friend WithEvents nudPickupItemDetailWidth As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudPickupItemDetailHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudPickupItemDetailLength As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudPickupItemDetailExtraCharges As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblPickupItemDetailExtraCharges As System.Windows.Forms.Label
    Friend WithEvents txtPickupItemDetailExtraChargesCurrency As System.Windows.Forms.TextBox
    Friend WithEvents nudPickupItemDetailCashAmount As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblPickupItemDetailCashAmount As System.Windows.Forms.Label
    Friend WithEvents txtPickupItemDetailCashAmountCurrency As System.Windows.Forms.TextBox
    Friend WithEvents lblPickupItemDetailVolume As System.Windows.Forms.Label
    Friend WithEvents lblPickupItemDetailVolumeUnit As System.Windows.Forms.Label
    Friend WithEvents cmbPickupItemDetailVolumeUnit As System.Windows.Forms.ComboBox
    Friend WithEvents nudPickupItemDetailVolume As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblPickupItemDetailWeight As System.Windows.Forms.Label
    Friend WithEvents lblPickupItemDetailWeightUnit As System.Windows.Forms.Label
    Friend WithEvents cmbPickupItemDetailWeightUnit As System.Windows.Forms.ComboBox
    Friend WithEvents nudPickupItemDetailWeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblPickupItemDetailComments As System.Windows.Forms.Label
    Friend WithEvents lblPickupItemDetailNumberOfPieces As System.Windows.Forms.Label
    Friend WithEvents colNumberOfPieces As System.Windows.Forms.ColumnHeader
    Friend WithEvents colWeight As System.Windows.Forms.ColumnHeader
    Friend WithEvents colVolume As System.Windows.Forms.ColumnHeader
    Friend WithEvents colCashAmount As System.Windows.Forms.ColumnHeader
    Friend WithEvents colExtraCharges As System.Windows.Forms.ColumnHeader
    Friend WithEvents colDimensions As System.Windows.Forms.ColumnHeader
    Friend WithEvents colComments As System.Windows.Forms.ColumnHeader
    Friend WithEvents gcPickupContact As System.Windows.Forms.GroupBox
    Friend WithEvents lblPickupContactType As System.Windows.Forms.Label
    Friend WithEvents lblPickupContactEmailAddress As System.Windows.Forms.Label
    Friend WithEvents lblPickupContactCellPhone As System.Windows.Forms.Label
    Friend WithEvents lblPickupContactFaxNumber As System.Windows.Forms.Label
    Friend WithEvents lblPickupContactPhoneNumber2 As System.Windows.Forms.Label
    Friend WithEvents lblPickupContactPhoneNumber1 As System.Windows.Forms.Label
    Friend WithEvents lblPickupContactCompanyName As System.Windows.Forms.Label
    Friend WithEvents lblPickupContactTitle As System.Windows.Forms.Label
    Friend WithEvents lblPickupContactPersonName As System.Windows.Forms.Label
    Friend WithEvents lblPickupContactDepartment As System.Windows.Forms.Label
    Friend WithEvents txtPickupContactType As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupContactEmailAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupContactCellPhone As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupContactFaxNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupContactPhoneNumber2Ext As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupContactPhoneNumber2 As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupContactPhoneNumber1Ext As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupContactPhoneNumber1 As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupContactCompanyName As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupContactTitle As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupContactPersonName As System.Windows.Forms.TextBox
    Friend WithEvents txtPickupContactDepartment As System.Windows.Forms.TextBox
    Friend WithEvents gcPickupStatus As System.Windows.Forms.GroupBox
    Friend WithEvents lblPickupStatus As System.Windows.Forms.Label
    Friend WithEvents txtPickupStatus As System.Windows.Forms.TextBox
    Friend WithEvents btnAddShipments As System.Windows.Forms.Button
    Friend WithEvents gcLabelInfo As System.Windows.Forms.GroupBox
    Friend WithEvents rbReportAsFile As System.Windows.Forms.RadioButton
    Friend WithEvents rbReportAsURL As System.Windows.Forms.RadioButton
    Friend WithEvents lblReportID As System.Windows.Forms.Label
    Friend WithEvents nudReportID As System.Windows.Forms.NumericUpDown
    Friend WithEvents chkbGenerateLabels As System.Windows.Forms.CheckBox
End Class
